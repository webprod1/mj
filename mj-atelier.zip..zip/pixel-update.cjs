const fs=require('fs');let h=fs.readFileSync('dist/index.html','utf8');
h=h.replace(/<img class="avatar"[^>]+>/,'<button class="pixel-avatar-button" type="button" aria-label="Make MJ wave hello again"><span class="pixel-avatar" role="img" aria-label="Close-up pixel avatar of MJ wearing glasses and a plain gray hoodie, waving hello"></span><span class="wave-hint">SAY HELLO <b>↗</b></span></button>');
h=h.replace('A CURIOUS MIND. A CREATIVE SOUL.','HEY, I’M MJ. NICE TO MEET YOU.');
h=h.replace(/<img src="assets\/mj-avatar.png"[^>]+>/,'<div class="about-pixel" role="img" aria-label="Close-up pixel portrait of MJ in a gray hoodie"></div>');
h=h.replace('<a href="#about">The approach <small>02</small></a>','').replace('Say hello <small>03</small>','Say hello <small>04</small>');
fs.writeFileSync('dist/index.html',h);
fs.appendFileSync('dist/script.js',`\n// Play a short greeting once the sprite is ready, and replay on activation.
const waveButton=document.querySelector('.pixel-avatar-button'),pixel=document.querySelector('.pixel-avatar');
let waveTimer=null;const waveFrames=[0,1,2,3,0,1,2,3,0,1,2,3,1];
function greet(){if(waveTimer)clearTimeout(waveTimer);if(reduced){pixel.style.backgroundPosition='33.333333% 50%';return}let index=0;waveButton.classList.add('greeting');const tick=()=>{pixel.style.backgroundPosition=(waveFrames[index]*100/3)+'% 50%';index++;if(index<waveFrames.length)waveTimer=setTimeout(tick,145);else{waveButton.classList.remove('greeting');waveTimer=null}};tick()}
const spriteImage=new Image();spriteImage.onload=()=>{waveButton.classList.add('ready');greet()};spriteImage.src='assets/mj-pixel-wave.png';waveButton.addEventListener('click',greet);
`);
console.log('Close-up pixel greeting installed.');
